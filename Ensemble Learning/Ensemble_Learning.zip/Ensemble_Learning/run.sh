#!/bin/bash

py Bagging