# Bringing in Pandas and Numpy
import numpy as np
from numpy.linalg import multi_dot
import pandas as pd
import random

def Perceptron_Averaged(D, T, r):
    w = np.asarray([0, 0, 0, 0, 0])
    a = np.asarray([0, 0, 0, 0, 0])
    for epoch in range(T):
        # np.random.seed(10)
        np.random.shuffle(D)
        for row in D:
            yi = row[-1]
            xi = row[0:-1]
            xi = np.append(xi, 1)

            intermediate = np.inner(w, xi)

            error = yi * intermediate

            if error <= 0:
                w = w + r * yi * xi
            a = a + w
    return a


# Converting 0's in training data set to -1's training data
x_vec = ['x_1', 'x_2', 'x_3', 'x_4', 'label']
all_data = pd.read_csv('train_bank_note.csv', names=x_vec)
data = all_data.iloc[1:500].copy()
data.loc[data['label'] == 0, 'label'] = -1

# Converting 0's in test data set to -1's in test data
x_vec_test = ['x_1', 'x_2', 'x_3', 'x_4', 'label']
all_data_test = pd.read_csv('test_bank_note.csv', names=x_vec)
data_test = all_data_test.iloc[1:500].copy()
data_test.loc[data_test['label'] == 0, 'label'] = -1

# Converting data frame to numpy array
data_array = data.to_numpy()

# Converting data frame to numpy array
data_array_test = data_test.to_numpy()

# Saving out original data frame for later comparison
data_orig = data_array.copy()
data_orig_test = data_array_test.copy()

# Setting number of epochs for and convergence rate for algorithm
T = 10
r = 0.01

# Calling function and printing result
a_returned = Perceptron_Averaged(data_array, T, r)
print('Averaged Perceptron weight vector is:')
print(a_returned)

# Creating x vector for prediction calculation training data
x_un_aug = data_orig[:, 0:-1]
x = np.ones((len(x_un_aug), x_un_aug.shape[1]+1))
x[:, :-1] = x_un_aug

# Creating x vector for prediction calculation test data
x_un_aug_test = data_orig_test[:, 0:-1]
x_test = np.ones((len(x_un_aug_test), x_un_aug_test.shape[1]+1))
x_test[:, :-1] = x_un_aug_test

# Generating prediction
prediction = np.sign(np.inner(a_returned, x))
prediction_test = np.sign(np.inner(a_returned, x_test))


# Determining percent error of training prediction and printing result
comp_array = np.equal(prediction, data_orig[:, -1])
percent_error = np.count_nonzero(comp_array == 0) / len(comp_array) * 100

# Determining percent error of test prediction and printing result
comp_array_test = np.equal(prediction_test, data_orig_test[:, -1])
percent_error_test = np.count_nonzero(comp_array_test == 0) / len(comp_array_test) * 100
print('Averaged Perceptron percent error for test data is:')
print(percent_error_test)