# Bringing in Pandas and Numpy
import numpy as np
from numpy.linalg import multi_dot
import pandas as pd
import random

def Perceptron_Voting(D, T, r):
    w = np.asarray([0, 0, 0, 0, 0])
    c = 0
    c_array = np.empty((0, 1), int)
    w_array = np.empty((0, len(w)), int)
    for epoch in range(T):
        # np.random.seed(10)
        np.random.shuffle(D)
        for row in D:
            yi = row[-1]
            xi = row[0:-1]
            xi = np.append(xi, 1)

            intermediate = np.inner(w, xi)

            error = yi * intermediate

            if error <= 0:
                # creating an array for the weight vector and counts
                w_array = np.vstack([w_array, w])
                c_array = np.vstack([c_array, c])
                w = w + r * yi * xi
                # resetting count
                c = 1
            else:
                c = c + 1
    return w_array, c_array


# Converting 0's in data set to -1's
x_vec = ['x_1', 'x_2', 'x_3', 'x_4', 'label']
all_data = pd.read_csv('train_bank_note.csv', names=x_vec)
data = all_data.iloc[1:500].copy()
data.loc[data['label'] == 0, 'label'] = -1

# Converting 0's in test data set to -1's in test data
x_vec_test = ['x_1', 'x_2', 'x_3', 'x_4', 'label']
all_data_test = pd.read_csv('test_bank_note.csv', names=x_vec)
data_test = all_data_test.iloc[1:500].copy()
data_test.loc[data_test['label'] == 0, 'label'] = -1

# Converting data frame to numpy array
data_array = data.to_numpy()

# Converting data frame to numpy array
data_array_test = data_test.to_numpy()

# Saving out original data frame for later comparison
data_orig = data_array.copy()
data_orig_test = data_array_test.copy()


# Setting number of epochs for and convergence rate for algorithm
T = 10
r = 0.01

# Calling function and printing result
w_array_returned, c_array_returned = Perceptron_Voting(data_array, T, r)
print('Voting Perceptron weight vectors')
print(w_array_returned)
print('Voting Perceptron counts')
print(c_array_returned)

# Creating x vector for prediction calculation
x_un_aug = data_orig[:, 0:-1]
x = np.ones((len(x_un_aug), x_un_aug.shape[1]+1))
x[:, :-1] = x_un_aug

# Creating x vector for prediction calculation test data
x_un_aug_test = data_orig_test[:, 0:-1]
x_test = np.ones((len(x_un_aug_test), x_un_aug_test.shape[1]+1))
x_test[:, :-1] = x_un_aug_test

# Generating prediction for training data
predictions = np.empty((0, 1), int)
for row_x in x:
    ith_w_predict = 0
    all_ith_w_predicts = np.empty((0, 1), int)
    for row_w, row_c in zip(w_array_returned, c_array_returned):
        ith_w_predict += row_c[0] * np.sign(np.inner(row_w, row_x))
    x_ith_summed = ith_w_predict
    x_ith_predict = np.sign(x_ith_summed)
    predictions = np.vstack([predictions, x_ith_predict])

    #     ith_w_predict = row_c * np.sign(np.inner(row_w, row_x))
    #     all_ith_w_predicts = np.vstack([all_ith_w_predicts, ith_w_predict])
    # x_ith_summed = np.atleast_1d(np.sum(all_ith_w_predicts))
    # x_ith_predict = np.sign(x_ith_summed)
    # predictions = np.vstack([predictions, x_ith_predict])

# Generating prediction for test data
predictions_test = np.empty((0, 1), int)
for row_x_test in x_test:
    ith_w_predict_test = 0
    all_ith_w_predicts_test = np.empty((0, 1), int)
    for row_w_test, row_c_test in zip(w_array_returned, c_array_returned):
        ith_w_predict_test += row_c_test[0] * np.sign(np.inner(row_w_test, row_x_test))
    x_ith_summed_test = ith_w_predict_test
    x_ith_predict_test = np.sign(x_ith_summed_test)
    predictions_test = np.vstack([predictions_test, x_ith_predict_test])


# Determining percent error of prediction and printing result
predictions = predictions[:, 0]
labels = np.array(data_orig[:, -1])
comp_array = np.equal(predictions, labels)
percent_error = np.count_nonzero(comp_array == 0) / len(comp_array) * 100

# Determining percent error of prediction and printing result
predictions_test = predictions_test[:, 0]
labels_test = np.array(data_orig_test[:, -1])
comp_array_test = np.equal(predictions_test, labels_test)
percent_error_test = np.count_nonzero(comp_array_test == 0) / len(comp_array_test) * 100
print('Voting Perceptron percent error is:')
print(percent_error_test)