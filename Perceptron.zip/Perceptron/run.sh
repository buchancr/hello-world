#!/bin/bash

py Perceptron_Standard.py
py Perceptron_Voting.py
py Perceptron_Averaged.py